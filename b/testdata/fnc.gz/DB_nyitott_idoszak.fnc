ALTER SESSION SET CURRENT_SCHEMA = BRUNO_OWNER;
SET DEFINE OFF SQLPREFIX OFF

FUNCTION DB_nyitott_idoszak(zaras_tipus IN VARCHAR2,
                            figyeles IN VARCHAR2 DEFAULT 'N') RETURN DATE IS
  darab PLS_INTEGER := 0;
  hataly DATE := NULL;
BEGIN
  IF figyeles = 'I' THEN
    SELECT COUNT(1) INTO darab
      FROM T_zarasok
      WHERE F_tipus = zaras_tipus AND F_statusz = '0000';
    IF darab > 0 THEN
      RETURN(NULL);
    END IF;
  END IF;
  BEGIN
    SELECT F_hataly INTO hataly
      FROM T_zart_idoszak
      WHERE F_tipus = zaras_tipus;
  EXCEPTION WHEN NO_DATA_FOUND THEN
    BEGIN
      IF zaras_tipus = LOWER(zaras_tipus) THEN
        SELECT F_hataly INTO hataly
          FROM T_zarasok
          WHERE F_tipus = UPPER(zaras_tipus) AND F_statusz = '0000';
      END IF;
    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
      SELECT F_hataly INTO hataly
        FROM T_zart_idoszak
        WHERE F_tipus = UPPER(zaras_tipus);
    END;
  END;
  RETURN(hataly);
END;

ALTER FUNCTION DB_NYITOTT_IDOSZAK
  COMPILE
    PLSQL_OPTIMIZE_LEVEL=2
    PLSQL_CODE_TYPE=INTERPRETED
    PLSQL_DEBUG=FALSE
    PLSCOPE_SETTINGS='IDENTIFIERS:NONE, STATEMENTS:NONE' 
  REUSE SETTINGS TIMESTAMP '2026-08-05 01:03:24';